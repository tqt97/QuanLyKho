<?php

return [
    'user' => 'Người dùng',
];
