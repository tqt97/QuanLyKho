<?php

return [
    'shops' => 'Cửa hàng',
    'accounts' => 'Tài khoản',
];
