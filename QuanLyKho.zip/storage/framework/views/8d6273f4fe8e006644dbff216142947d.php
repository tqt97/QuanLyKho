<div <?php echo e($attributes->class(['flex gap-x-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH F:\laravel\6-Ly\QuanLyKho\vendor\filament\forms\src\/../resources/views/components/rich-editor/toolbar/group.blade.php ENDPATH**/ ?>